   
function check(gender, shortBreath, chestPain){
let count = 0;
 // let gender = document.getElementById("gender").value;
  //let shortBreath = document.getElementById("shortBreath").value;
//  let chestPain = document.getElementById("chestPain").value;

//male  
if(gender==male){
  if(age>45){
    count++;
  }
  if(shortBreath==yes){
    count+=2
  }
   if(chestPain==yes){
    count+=2
  }
  if(ldl > 160){
    count+=3
  }
  if(hdl < 40){
    count+=3
  }
  if(triglycerides > 150){
    count+=3
  }
  if(family==yes){
    count++
  }
    if(legs==yes){
    count+=2
  }
    if(smoke==yes){
    count+=2
  }
}
//female
else{
  if(gender==female){
  if(age>50){
    count++;
  }
     if(shortBreath==yes){
    count+=2
  }
    if(chestPain==yes){
    count+=2
  }
    if(ldl > 160){
    count+=3
  }
    if(hdl < 40){
    count+=3
  }
    if(triglycerides > 150){
    count+=3
  }
    if(family==yes){
    count++
  }
    if(legs==yes){
    count+=2
  }
    if(smoke==yes){
    count+=2
  }
}
}
  let msg = "";
 const output = document.getElementById("msgOut").value; 
if(count>5){
  msg += "You are at high risk for heart disease";
}
else if(count > 3){
  msg += "You are at moderate risk for heart disease";
}
else{
  msg += "You are at low risk of heart disease";
}
  document.getElementById("result").innerHTML;
}